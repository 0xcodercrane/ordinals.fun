export const padding = 546;
export const base_size = 160;
export const feeAmount = 3000;
export const encodedAddressPrefix = 'main'
export const mempoolNetwork = ''
export const feeAddress = process.env.NEXT_PUBLIC_FEE_ADDRESS ||
  'bc1pvepyhmkjnm7luu66unxxnzqpee5lpzunzqrgtf72ydwpwkx462eqy4dp0h'