import React from 'react'

export default function LTC20ListModalOnPage() {
  return (
    <div>LTC20ListModalOnPage</div>
  )
}
