function Spinner() {
  return <div class='infinity-10'></div>
}

export default Spinner
