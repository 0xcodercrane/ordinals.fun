import React from "react";

export default function LTC20() {
  return (
    <div className="my-auto flex flex-col justify-center items-center">
      <h1 className="text-5xl font-bold mb-8 animate-pulse">Coming Soon</h1>
    </div>
  );
}
